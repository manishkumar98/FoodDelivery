package com.example.p1;

public class GlobalVariable {
    public static Boolean flag = false;
    public static String phoneUser="+918919317644";
    public static String phoneRider="+917976254938";
    public static String receiverLat = "17.43990";
    public static String receiverLong="78.4983";
    public static Double delPointDistance= 0.0;
    public static Double userLat=0.0;
    public static  Double userLong=0.0;
    public static String indication="false";

}
